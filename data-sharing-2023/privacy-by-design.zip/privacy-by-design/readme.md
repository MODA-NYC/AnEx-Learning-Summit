# Purpose

Educational content on privacy-by-design principles and applications. Can serve as a wiki on the topic.

See details about [JupyterBooks](https://jupyterbook.org/en/stable/intro.html).

# How to Use

## Contribution

To contribute, modify the markdown and the yaml files. Once modified, build the book.

## Build the Book

At the command prompt, type
`jupyter-book build <path-to-book>`. This will create a `_build` folder containing the static site. See more details [here](https://jupyterbook.org/en/stable/basics/build.html).

## Open the Book

Open `_build\html\index.html`. This will open the static site locally.

# Publish Online

The book can be published online. See [Publish your book online](https://jupyterbook.org/en/stable/basics/build.html).