---
jupytext:
  formats: md:myst
  text_representation:
    extension: .md
    format_name: myst
kernelspec:
  display_name: Python 3
  language: python
  name: python3
---

# Data Science Project

::::{grid}
:gutter: 3

:::{grid-item-card}
:class-header: bg-light text-center

Principles
^^^

1. `Prevent disclosure` Prevent disclosure of data and secrets. Be proactive, not reactive. Avoid having to perform cleanups.
1. `Default Setting` Make privacy a default setting. Choose settings that safeguard data and secrets.
1. `Core Component` Make privacy a core component. Treat it like a software component.
1. `Minimize Trade-Offs` Minimize trade-offs with other legitimate objectives. Do your best not to sacrifice privacy for functionality.
1. `Full Lifecycle` Provide full lifecycle protection. Privacy during collection and use. Delete and archive properly.
1. `Visible` Make privacy components visible. People whose data you process should know how you handle the data.
1. `User Privacy` Respect user privacy. Give the user the power to control use of their data and the power to withdraw consent to use their data.

:::
::::

::::{grid}
:gutter: 3

:::{grid-item-card}
:class-header: bg-light text-center

Configuration Files
^^^

- `Separate Code & Secrets`
    - Place secrets in `config` files.
    - Add `config` file to `.gitignore`.
- `Configuration File Types` Can use `JSON`, `yaml`, `toml`. Also see `pydantic`, `hydra-core` (Meta), `tomllib` or `tomli` (PyPi).
- `Advantage` Improved portability because configuration is specified in the project.
- `Disadvantages` Multiple configuration files means multiple secrets files in multiple projects. Secrets not encrypted, although can encrypt with `cryptography` (PyPi). Avoid storing `config` files on shared drives.

:::
::::

::::{grid}
:gutter: 3

:::{grid-item-card}
:class-header: bg-light text-center

Environment Variables
^^^

- `Separate Code & Secrets`
    - Without using PyPi packages.
        - Store secrets in your machine's environment variables, not in `config` files. Can use [PowerShell](https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.core/about/about_environment_variables?view=powershell-7.3).
        - `Advantage` Can't easily push environment variables to remote.
        - `Disadvantage` Environment variables are tied to the machine, so this solution isn't portable.
    - Using PyPi packages (e.g., [`python-dotenv`](https://pypi.org/project/python-dotenv/)).
        - Store secrets either in (1) your machine's environment variables, or (2) in an `.env` file, which acts as a `config` file.

:::
::::


::::{grid}
:gutter: 3

:::{grid-item-card}
:class-header: bg-light text-center

Cloud Secrets Managers
^^^

- `Centralized` Secrets in centralized location, rather than being sprawled in various configuration files.
- `Encrypted` Secrets are encrypted, so they are not visible to unauthorized users.
- `Control` Fine-grained control over who can read, write, and manage secrets.
- e.g., [Azure Key Vault](https://learn.microsoft.com/en-us/azure/key-vault/general/overview) (free with Azure DevOps), [AWS Secrets Manager](https://aws.amazon.com/secrets-manager/), [Secret Manager](https://cloud.google.com/secret-manager/docs) | Google Cloud, [HashiCorp's Vault](https://www.hashicorp.com/products/vault).

::::
