# Privacy by Design

The main idea of privacy-by-design is to use technology design to protect data.
These [principles](./docs/data-science-project.md) are meant to guide your thought process while you are dealing with the minutia of software design. They are just principles, not a set of rules you must follow. Also, depending on where you are in the project, some principles may apply, some may not, and they apply to different degrees. Think of them as faders on an audio mixing board.